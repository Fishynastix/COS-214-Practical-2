#include "OrderState.h"

void ReadyState::processOrder(Order* order) {
    std::cout << "Order moving from " + this->getStateName() + " to Delivered" << std::endl;
    order->setState(new DeliveredState());
}

void ReadyState::cancelOrder(Order* order) {
    std::cout << "Order reverted from " + this->getStateName() + " to Pending" << std::endl;
    order->setState(new PendingState()); // Backward transition
}

std::string ReadyState::getStateName() {
    return "Ready";
}

void DeliveredState::processOrder(Order* order) {
    std::cout << "Error: Cannot process a delivered order" << std::endl;
}

void DeliveredState::cancelOrder(Order* order) {
    std::cout << "Error: Cannot cancel a delivered order" << std::endl;
}

std::string DeliveredState::getStateName() {
    return "Delivered";
}

void PreparingState::processOrder(Order* order) {
    std::cout << "Order moving from " + this->getStateName() + " to Ready" << std::endl;
    order->setState(new ReadyState());
}

void PreparingState::cancelOrder(Order* order) {
    std::cout << "Order reverted from " + this->getStateName() + " to Pending" << std::endl;
    order->setState(new PendingState()); // Backward transition
}

std::string PreparingState::getStateName() {
    return "Preparing";
}

void PendingState::processOrder(Order* order) {
    std::cout << "Order moving from " + this->getStateName() + " to Preparing" << std::endl;
    order->setState(new PreparingState());
}

void PendingState::cancelOrder(Order* order) {
    std::cout << "Order cancelled in " + this->getStateName() + " state" << std::endl;
    order->setState(nullptr); // Or a CancelledState
}

std::string PendingState::getStateName() {
    return "Pending";
}
